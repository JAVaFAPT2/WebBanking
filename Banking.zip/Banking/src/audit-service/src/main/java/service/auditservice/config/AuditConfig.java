package service.auditservice.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AuditConfig {
    // Add additional configuration as needed (e.g., bean definitions for audit aspects)
}