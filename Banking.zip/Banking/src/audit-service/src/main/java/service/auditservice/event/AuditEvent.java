package service.auditservice.event;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Entity representing an audit event.
 */
@Entity
@Table(name = "audit_events")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AuditEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private UUID id;

    @Column(nullable = false)
    private String level;

    @Column(nullable = false, length = 1024)
    private String message;

    @Column(nullable = false)
    private LocalDateTime timestamp;

    @Column
    private String serviceName;
}