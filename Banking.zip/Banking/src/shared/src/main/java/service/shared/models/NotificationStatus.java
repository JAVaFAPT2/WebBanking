package service.shared.models;

public enum NotificationStatus {
    READ,
    UNREAD,
    DELIVERED,
    FAILED
}
