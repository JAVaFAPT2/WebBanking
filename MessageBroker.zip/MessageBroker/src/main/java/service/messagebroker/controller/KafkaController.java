package service.messagebroker.controller;

public class KafkaController {
}
