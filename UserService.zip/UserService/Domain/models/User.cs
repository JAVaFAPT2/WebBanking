﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain.models
{
    public class User
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; private set; }

        [Required]
        [StringLength(100)]
        public string Name { get; private set; }

        [Required]
        [StringLength(100)]
        public string Email { get; private set; }

        [Required]
        public string PasswordHash { get; private set; }

        [Required]
        public DateTime CreatedAt { get; private set; }

        public User()
        {
        }
        public void Update(string name, string email)
        {
            Name = name;
            Email = email;
        }
        public User(Guid id, string name, string email, string passwordHash, DateTime createdAt)
        {
            Id = id;
            Name = name;
            Email = email;
            this.PasswordHash = passwordHash;
            CreatedAt = createdAt;
        }

        public User(string name, string email, string passwordHash)
        {
            Name = name;
            Email = email;
            this.PasswordHash = passwordHash;
        }

        public override bool Equals(object? obj)
        {
            return obj is User user &&
                   Id.Equals(user.Id) &&
                   Name == user.Name &&
                   Email == user.Email &&
                   PasswordHash == user.PasswordHash &&
                   CreatedAt == user.CreatedAt;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Id, Name, Email, PasswordHash, CreatedAt);
        }
    }
}
