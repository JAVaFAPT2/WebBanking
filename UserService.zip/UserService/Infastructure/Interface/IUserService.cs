﻿using Application.CQRS.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Interface
{
    public interface IUserService
    {
        Task CreateUserAsync(CreateUserCommand command);
        Task UpdateUserAsync(UpdateUserCommand command);
        Task DeleteUserAsync(Guid userId);
        Task<object?> GetUserByIdAsync(Guid userId);

        Task<IEnumerable<object>> GetAllUsersAsync();

        Task<object?> GetUserByEmailAsync(string email);
    }
}
