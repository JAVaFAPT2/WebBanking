﻿using MediatR;
using Domain.Interface;
using BCrypt.Net;
using Application.CQRS.Commands;
using Domain.models;

public class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, Guid>
{
    private readonly IUserRepository _userRepository;

    public CreateUserCommandHandler(IUserRepository userRepository)
    {
        _userRepository = userRepository;
    }

    public async Task<Guid> Handle(CreateUserCommand request, CancellationToken cancellationToken)
    {
        // Hash the password
        string hashedPassword = BCrypt.Net.BCrypt.HashPassword(request.Password);

        // Create a new user entity
        var user = new User
        {
            Id = Guid.NewGuid(),
            Name = request.UserName,
            Email = request.Email,
            PasswordHash = hashedPassword
        };

        // Use AddAsync instead of CreateAsync
        await _userRepository.AddAsync(user);

        return user.Id;
    }
}

