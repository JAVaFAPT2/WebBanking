﻿
using MediatR;

namespace Application.CQRS.Commands
{
    public record CreateUserCommand(string UserName, string Email, string Password) : IRequest<Guid>;
}